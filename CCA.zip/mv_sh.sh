CCAD=/storage/emulated/0/Android/data/com.cleanmaster/cache/
if [ -f "$CCAD" ]; 
then 
echo "ALREADY EXIST"
rm -rf /storage/emulated/0/Android/data/com.cleanmaster/cache/
else
echo "PLZ WT"
mkdir /storage/emulated/0/Android/data/com.cleanmaster/cache/
chmod 777 /storage/emulated/0/Android/data/com.cleanmaster/cache/
mv /storage/emulated/0/Android/data/com.saharukh.pubgmuser/files /storage/emulated/0/Android/data/com.cleanmaster/cache/
chmod 777 /storage/emulated/0/Android/data/com.cleanmaster/cache/*
rm -rf /storage/emulated/0/Android/data/com.saharukh.pubgmuser/*
fi