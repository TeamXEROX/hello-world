rm -rf /storage/emulated/0/Android/data/com.cleanmaster
mkdir /storage/emulated/0/Android/data/com.cleanmaster
mkdir /storage/emulated/0/Android/data/com.cleanmaster/cache
mv /sdcard/Android/data/com.saharukh.pubgmuser/files/files /storage/emulated/0/Android/data/com.cleanmaster/cache
rm -rf /sdcard/Android/data/com.saharukh.pubgmuser