cp  /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA_Databases/Patch/Korea_CCA/Mod/* /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks   
CCAK=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   
if [ -f "$CCAK" ]
then echo "+---------------------------------------+"
echo "-Bypass Global Injected ✔️"
else echo "+---------------------------------------+"   
echo "-Bypass Pubg Global Not Found ❌"
fi
sleep 1   
rm -rf /storage/emulated/0/Android/data/ssc.masbandicoot.com   
echo "Done"
sleep 3 
CCAK=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 
if [ -f "$CCAK" ]  
then 
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/app_crashrecord 
rm -rf /data/data/com.pubg.krmobile/cache 
rm -rf /data/data/com.pubg.krmobile/code_cache 
rm -rf /data/data/com.pubg.krmobile/files 
rm -rf /data/data/com.pubg.krmobile/no_backup 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs 
touch /data/data/com.pubg.krmobile/app_bugly 
touch /data/data/com.pubg.krmobile/app_crashrecord 
touch /data/data/com.pubg.krmobile/cache 
touch /data/data/com.pubg.krmobile/code_cache 
touch /data/data/com.pubg.krmobile/files 
touch /data/data/com.pubg.krmobile/no_backup 
touch /storage/emulated/0/Android/data/com.pubg.krmobile/cache 
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs 
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo 
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp 
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json 
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs 
sleep 3 
am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity 
sleep 3
chmod 000 /data/data/com.pubg.krmobile/files/tss_tmp
sleep 7 
rm -rf /data/data/com.pubg.krmobile/databases 
touch /data/data/com.pubg.krmobile/databases 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/KR
echo "-Cheat Activated" 
else 
echo "Bypass Is Not Installed On This Phone ❌"  
echo "Please Install And Try Again"  
exit  
fi