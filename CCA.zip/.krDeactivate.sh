echo "-Please Wait!" 
rm -rf /data/data/com.pubg.krmobile/databases 
rm -rf /data/data/com.pubg.krmobile/app_bugly 
rm -rf /data/data/com.pubg.krmobile/app_crashrecord 
rm -rf /data/data/com.pubg.krmobile/cache 
rm -rf /data/data/com.pubg.krmobile/code_cache 
rm -rf /data/data/com.pubg.krmobile/files 
rm -rf /data/data/com.pubg.krmobile/no_backup 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs 
pm install -r /data/app/com.pubg.krmobile*/base.apk 
rm -r /storage/emulated/0/CCA/
echo "-Cheat Has Been Deactivated"  