rm -rf /storage/emulated/0/Android/data/ssc.masbandicoot.com   
rm -rf /storage/emulated/0/Android/data/com.clash.mobi   
rm -rf /storage/emulated/0/Android/data/com.mobile.android   
rm -rf /storage/emulated/0/Android/data/com.gvendor.android   
sleep 2   
echo "Checking!"
sleep 4   
cp  /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA_Databases/Patch/Taiwan_CCA/Mod/* /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks   
CCAT=/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   
if [ -f "$CCAT" ]
then echo "+---------------------------------------+"
echo "-Bypass Global Injected ✔️"
else echo "+---------------------------------------+"   
echo "-Bypass Pubg Global Not Found ❌"
fi
sleep 1   
rm -rf /storage/emulated/0/Android/data/ssc.masbandicoot.com   
echo "Done"
sleep 3 
CCAT=/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 
if [ -f "$CCAT" ]  
then 
rm -rf /data/data/com.rekoo.pubgm/app_bugly
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord 
rm -rf /data/data/com.rekoo.pubgm/cache 
rm -rf /data/data/com.rekoo.pubgm/code_cache 
rm -rf /data/data/com.rekoo.pubgm/files 
rm -rf /data/data/com.rekoo.pubgm/no_backup 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json 
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs 
touch /data/data/com.rekoo.pubgm/app_bugly 
touch /data/data/com.rekoo.pubgm/app_crashrecord 
touch /data/data/com.rekoo.pubgm/cache 
touch /data/data/com.rekoo.pubgm/code_cache 
touch /data/data/com.rekoo.pubgm/files 
touch /data/data/com.rekoo.pubgm/no_backup 
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/cache 
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs 
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo 
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp 
mkdir /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json 
mkdir /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs 
sleep 3 
am start -n com.rekoo.pubgm/com.epicgames.ue4.SplashActivity 
sleep 3
chmod 000 /data/data/com.rekoo.pubgm/files/tss_tmp
sleep 7 
rm -rf /data/data/com.rekoo.pubgm/databases 
touch /data/data/com.rekoo.pubgm/databases 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/TW
echo "-Cheat Activated" 
else 
echo "Bypass Is Not Installed On This Phone ❌"  
echo "Please Install And Try Again"  
exit  
fi