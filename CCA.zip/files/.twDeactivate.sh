rm -rf /data/data/com.rekoo.pubgm/databases
rm -rf /data/data/com.rekoo.pubgm/app_bugly
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/cache
rm -rf /data/data/com.rekoo.pubgm/code_cache
rm -rf /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/no_backup
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
pm install -r /data/app/com.rekoo.pubgm*/base.apk
