rm -rf /storage/emulated/0/CCA

cp -R /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Global/* /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

CCAM=/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 

if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
rm -rf /data/data/com.tencent.ig/cache   
rm -rf /data/data/com.xmxlkbex/cache   
rm -rf /storage/emulated/0/Android/data/com.xmxlkbex   
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache   
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi


CCAM=/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   

if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/GL
echo ""
rm -rf /data/data/com.tencent.ig/app_bugly
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/no_backup
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
touch /data/data/com.tencent.ig/app_bugly
touch /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/cache
touch /data/data/com.tencent.ig/code_cache
touch /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/no_backup
touch /storage/emulated/0/Android/data/com.tencent.ig/cache
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
sleep 3
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 5
rm -rf /data/data/com.tencent.ig/databases
touch /data/data/com.tencent.ig/databases
else 
echo ""
fi






