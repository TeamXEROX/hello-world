rm -rf /storage/emulated/0/CCA

cp -R /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Global/* /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

CCAM=/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 

if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
rm -rf /data/data/com.tencent.ig/cache   
rm -rf /data/data/com.xmxlkbex/cache   
rm -rf /storage/emulated/0/Android/data/com.xmxlkbex   
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache   
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi


CCAM=/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   

if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/GL
echo ""
 ip6tables -P INPUT DROP
 ip6tables -P OUTPUT DROP
 ip6tables -P FORWARD DROP
 iptables -A INPUT -m string --algo bm --string "qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "tencent.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "tencent.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "tencent.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "helpshift.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "helpshift.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "helpshift.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "oth.eve.mdt.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "oth.eve.mdt.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "oth.eve.mdt.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "myapp.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "myapp.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "myapp.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "android.bugly.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "android.bugly.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "android.bugly.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "dldir1.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "dldir1.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "dldir1.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "oth.str.mdt.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "oth.str.mdt.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "oth.str.mdt.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "qm.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "qm.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "qm.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "mail.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "mail.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "mail.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "proximabeta.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "proximabeta.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "proximabeta.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "pubgmobile.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "pubgmobile.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "pubgmobile.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "tpns.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "tpns.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "tpns.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "receiver.sg.tdm.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "receiver.sg.tdm.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "receiver.sg.tdm.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "sg.tdm.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "sg.tdm.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "sg.tdm.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "cloud.gsdk.proximabeta.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "cloud.gsdk.proximabeta.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "cloud.gsdk.proximabeta.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "vmp.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "vmp.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "vmp.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "csoversea.mbgame.gamesafe.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "csoversea.mbgame.gamesafe.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "csoversea.mbgame.gamesafe.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "userapi.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "userapi.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "userapi.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "gameguardian.net" -j DROP
 iptables -A FORWARD -m string --algo bm --string "gameguardian.net" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "gameguardian.net" -j DROP
 iptables -A INPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "intldlgs.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
 iptables -A INPUT -m string --algo bm --string "down.qq.com" -j DROP
 iptables -A FORWARD -m string --algo bm --string "down.qq.com" -j DROP
 iptables -A OUTPUT -m string --algo bm --string "down.qq.com" -j DROP
 sleep 1
 rm -rf /data/data/com.tencent.ig/app_bugly
 rm -rf /data/data/com.tencent.ig/app_crashrecord
 rm -rf /data/data/com.tencent.ig/cache
 rm -rf /data/data/com.tencent.ig/code_cache
 rm -rf /data/data/com.tencent.ig/files
 rm -rf /data/data/com.tencent.ig/no_backup
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
 rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
 touch /data/data/com.tencent.ig/app_bugly
 touch /data/data/com.tencent.ig/app_crashrecord
 touch /data/data/com.tencent.ig/cache
 touch /data/data/com.tencent.ig/code_cache
 touch /data/data/com.tencent.ig/files
 touch /data/data/com.tencent.ig/no_backup
 touch /storage/emulated/0/Android/data/com.tencent.ig/cache
 touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
 mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
 mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
 sleep 3
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 5
rm -rf /data/data/com.tencent.ig/databases
touch /data/data/com.tencent.ig/databases
else 
echo ""
fi






