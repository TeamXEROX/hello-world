rm -rf /storage/emulated/0/CCA

cp -R /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Global/* /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

CCAM=/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 

if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
rm -rf /data/data/com.rekoo.pubgm/cache   
rm -rf /data/data/com.xmxlkbex/cache   
rm -rf /storage/emulated/0/Android/data/com.xmxlkbex   
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache   
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi


CCAM=/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   

if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/TW
echo ""
rm -rf /data/data/com.rekoo.pubgm/app_bugly
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/cache
rm -rf /data/data/com.rekoo.pubgm/code_cache
rm -rf /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/no_backup
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
touch /data/data/com.rekoo.pubgm/app_bugly
touch /data/data/com.rekoo.pubgm/app_crashrecord
touch /data/data/com.rekoo.pubgm/cache
touch /data/data/com.rekoo.pubgm/code_cache
touch /data/data/com.rekoo.pubgm/files
touch /data/data/com.rekoo.pubgm/no_backup
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/cache
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
mkdir /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
mkdir /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
sleep 3
am start -n com.rekoo.pubgm/com.epicgames.ue4.SplashActivity
sleep 5
rm -rf /data/data/com.rekoo.pubgm/databases
touch /data/data/com.rekoo.pubgm/databases
else 
echo ""
fi






