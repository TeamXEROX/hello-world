rm -rf /storage/emulated/0/CCA
CCAL=/sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam/core_patch_0.17.0.11808.pak
if [ -f "$CCAL" ]
then 
echo ""
else
cp /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_149_0.17.0.11808_20200408093333_309756982_cures.ifs.res /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_0.17.0.11808.pak /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam > /dev/null 2>&1
fi
CCAM=/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak
if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
cp -R /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Mod/Vietnam/* /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/data/com.vng.pubgmobile/cache   
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache   
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi
CCAM=/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak
if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/VN
echo ""
rm -rf /data/data/com.vng.pubgmobile/lib/libtersafe.so
cp -R /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/lib/Vietnam/libtersafe.so /data/data/com.vng.pubgmobile/lib/
chmod -R 755 /data/data/com.vng.pubgmobile/lib/libtersafe.so
chown 1000:1000 /data/data/com.vng.pubgmobile/lib/libtersafe.so
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt
rm -rf /data/data/com.vng.pubgmobile/app_bugly
rm -rf /data/data/com.vng.pubgmobile/app_crashrecord > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/cache > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/code_cache > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/files > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/no_backup > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/app_bugly > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/app_crashrecord > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/cache > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/code_cache > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/files > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/no_backup > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.vng.pubgmobile/cache > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp > /dev/null 2>&1
 mkdir /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json > /dev/null 2>&1
 mkdir /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs > /dev/null 2>&1
 sleep 3 > /dev/null 2>&1
 am start -n com.vng.pubgmobile/com.epicgames.ue4.SplashActivity > /dev/null 2>&1
 sleep 5 > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/databases > /dev/null 2>&1
 touch /data/data/com.vng.pubgmobile/databases > /dev/null 2>&1
 else 
 echo "Bypass Is Not Installed" > /dev/null 2>&1
 fi




