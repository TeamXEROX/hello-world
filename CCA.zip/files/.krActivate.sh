rm -rf /storage/emulated/0/CCA
CCAL=/sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Korean/core_patch_0.17.0.11808.pak
if [ -f "$CCAL" ]
then 
echo ""
else
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1950038955_3090_0.17.0.11808_20200408012346_1754866465_cures.ifs.res /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Korean > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Korean > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Korean > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_0.17.0.11808.pak /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Korean > /dev/null 2>&1
fi
CCAM=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak
if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
cp -R /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Mod/Korean/* /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/data/com.pubg.krmobile/cache   
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache   
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi
CCAM=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak
if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/KR
echo ""
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/app_crashrecord > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/cache > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/code_cache > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/files > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/no_backup > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/app_bugly > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/app_crashrecord > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/cache > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/code_cache > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/files > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/no_backup > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.pubg.krmobile/cache > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo > /dev/null 2>&1
 touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp > /dev/null 2>&1
 mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json > /dev/null 2>&1
 mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs > /dev/null 2>&1
 sleep 3 > /dev/null 2>&1
 am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity > /dev/null 2>&1
 sleep 5 > /dev/null 2>&1
 rm -rf /data/data/com.pubg.krmobile/databases > /dev/null 2>&1
 touch /data/data/com.pubg.krmobile/databases > /dev/null 2>&1
 else 
 echo "Bypass Is Not Installed" > /dev/null 2>&1
 fi




