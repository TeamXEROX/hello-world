rm -rf /storage/emulated/0/CCA

cp -R /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Korean/* /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

CCAM=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak 

if [ -f "$CCAM" ]; 
then 
echo ""
else
echo ""
rm -rf /data/data/com.pubg.krmobile/cache   
rm -rf /data/data/com.xmxlkbex/cache   
rm -rf /storage/emulated/0/Android/data/com.xmxlkbex   
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache   
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs   
fi


CCAM=/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.17.0.11801.pak   

if [ -f "$CCAM" ]
then 
mkdir /storage/emulated/0/CCA
mkdir /storage/emulated/0/CCA/KR
echo ""
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/code_cache
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/no_backup
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
touch /data/data/com.pubg.krmobile/app_bugly
touch /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/cache
touch /data/data/com.pubg.krmobile/code_cache
touch /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/no_backup
touch /storage/emulated/0/Android/data/com.pubg.krmobile/cache
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
sleep 3
am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
sleep 5
rm -rf /data/data/com.pubg.krmobile/databases
touch /data/data/com.pubg.krmobile/databases
else 
echo ""
fi






