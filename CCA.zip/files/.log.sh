rm -rf /storage/emulated/0/Android/data/com.saharukh.pubgmuser/Files/CCA.zip
echo "Lobby"
GLOBAL()
{
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "Global Version Junks Cleaned."
echo "Coded by CCA"
}
KR()
{
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "Global Version Junks Cleaned."
echo "Coded by CCA"
}
VN()
{
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "VN Version Junks Cleaned."
echo "Coded by CCA"
}
TW()
{
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "TW Version Junks Cleaned."
echo "Coded by CCA"
}
if [ -d "/storage/emulated/0/CCA/GL" ];
then
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 10
CCA='com.tencent.ig'
while [ $(pidof $CCA) ]
do
GLOBAL
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/KR" ];
then
am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
sleep 10
CCA='com.pubg.krmobile'
while [ $(pidof $CCA) ]
do
KR
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/VN" ];
then
am start -n com.vng.pubgmobile/com.epicgames.ue4.SplashActivity
sleep 10
CCA='com.vng.pubgmobile'
while [ $(pidof $CCA) ]
do
VN
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/TW" ];
then
am start -n com.rekoo.pubgm/com.epicgames.ue4.SplashActivity
sleep 10
CCA='com.rekoo.pubgm'
while [ $(pidof $CCA) ]
do
TW
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
