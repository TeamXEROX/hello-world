PKGG="com.tencent.ig"
PKGK="com.pubg.krmobile"
PKGV="com.vng.pubgmobile"
PKGT="com.rekoo.pubgm"

GLOBAL()
{
rm -rf /storage/emulated/0/Android/data/$PKGG/cache
rm -rf /storage/emulated/0/Android/data/$PKGG/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/$PKGG/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/files/tbslog
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload/
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /storage/emulated/0/Android/data/$PKGG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /storage/emulated/0/Android/data/$PKGG/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGG/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGG/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGG/*/*/*/*/*/*/*/*/*.log
rm -rf /data/data/$PKGG/app*/*
rm -rf /data/data/$PKGG/no*/*
rm -rf /data/data/$PKGG/cache/*
rm -rf /data/data/$PKGG/code_cache/*
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "Global Version Junks Cleaned."
echo "Coded by CCA"
}
KR()
{
rm -rf /storage/emulated/0/Android/data/$PKGK/cache
rm -rf /storage/emulated/0/Android/data/$PKGK/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/$PKGK/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/files/tbslog
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload/
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /storage/emulated/0/Android/data/$PKGK/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /storage/emulated/0/Android/data/$PKGK/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGK/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGK/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGK/*/*/*/*/*/*/*/*/*.log
rm -rf /data/data/$PKGK/app*/*
rm -rf /data/data/$PKGK/no*/*
rm -rf /data/data/$PKGK/cache/*
rm -rf /data/data/$PKGK/code_cache/*
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "Global Version Junks Cleaned."
echo "Coded by CCA"
}
VN()
{
rm -rf /storage/emulated/0/Android/data/$PKGV/cache
rm -rf /storage/emulated/0/Android/data/$PKGV/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/$PKGV/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/files/tbslog
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload/
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /storage/emulated/0/Android/data/$PKGV/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /storage/emulated/0/Android/data/$PKGV/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*/*.json
rm -rf /storage/emulated/0/Android/data/$PKGV/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*/*.txt
rm -rf /storage/emulated/0/Android/data/$PKGV/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*.log
rm -rf /storage/emulated/0/Android/data/$PKGV/*/*/*/*/*/*/*/*/*.log
rm -rf /data/data/$PKGV/app*/*
rm -rf /data/data/$PKGV/no*/*
rm -rf /data/data/$PKGV/cache/*
rm -rf /data/data/$PKGV/code_cache/*
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "VN Version Junks Cleaned."
echo "Coded by CCA"
}
TW()
{
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
echo "TW Version Junks Cleaned."
echo "Coded by CCA"
}
if [ -d "/storage/emulated/0/CCA/GL" ];
then
am start -n $PKGG/com.epicgames.ue4.SplashActivity
CCA='$PKGG'
while [ $(pidof $CCA) ]
do
GLOBAL
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/KR" ];
then
am start -n $PKGK/com.epicgames.ue4.SplashActivity
CCA='$PKGK'
while [ $(pidof $CCA) ]
do
KR
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/VN" ];
then
am start -n $PKGV/com.epicgames.ue4.SplashActivity
CCA='$PKGV'
while [ $(pidof $CCA) ]
do
VN
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/CCA/TW" ];
then
am start -n $PKGT/com.epicgames.ue4.SplashActivity
CCA='$PKGT'
while [ $(pidof $CCA) ]
do
TW
((COUNT=$COUNT+10))
if [ ! $(pidof $CCA) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi