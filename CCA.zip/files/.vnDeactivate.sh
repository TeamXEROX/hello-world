rm -rf /data/data/com.vng.pubgmobile/databases
rm -rf /data/data/com.vng.pubgmobile/app_bugly
rm -rf /data/data/com.vng.pubgmobile/app_crashrecord
rm -rf /data/data/com.vng.pubgmobile/cache
rm -rf /data/data/com.vng.pubgmobile/code_cache
rm -rf /data/data/com.vng.pubgmobile/files
rm -rf /data/data/com.vng.pubgmobile/no_backup
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
pm install -r /data/app/com.vng.pubgmobile*/base.apk
