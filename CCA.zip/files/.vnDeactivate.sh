 cp /sdcard/Android/data/com.cleanmaster/cache/files/.CCA/Bak/Vietnam/* /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/databases > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/app_bugly > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/app_crashrecord > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/cache > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/code_cache > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/files > /dev/null 2>&1
 rm -rf /data/data/com.vng.pubgmobile/no_backup > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json > /dev/null 2>&1
 rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs > /dev/null 2>&1
 pm install -r /data/app/com.vng.pubgmobile*/base.apk > /dev/null 2>&1
 