if [ -d "/storage/emulated/0/CCA/GL" ];
then
rm -rf /storage/emulated/0/CCA
export DATA="/data/data"
export DATAMEDIA="/data/media/0/Android/data"
export PACKAGE="com.tencent.ig"
export FILES="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
export MEDIA="/data/media/0"
chmod -R 777 /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/*/* > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/game_patch*.pak > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/core_patch*.pak > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/lib > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/files > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/app_crashrecord > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/code_cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/no_backups > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/databases > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/vmpcloudconfig.json > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/login-identifier.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/cacheFile.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/ca-bundle.pem > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Engine > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/"Epic Games" > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Paks > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/afd > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/IGH5Cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/PufferTmpDir > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/RoleInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Pandora > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Screenshots > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/UpdateInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content > /dev/null 2>&1
su -c pm install -r /data/app/$PACKAGE*/base.apk /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/lib/* > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/* > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Ori/SrcVersion.ini /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/ > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Global/* /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks > /dev/null 2>&1
ip6tables -P INPUT ACCEPT
ip6tables -P OUTPUT ACCEPT
ip6tables -P FORWARD ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
fi
if [ -d "/storage/emulated/0/CCA/KR" ];
then
rm -rf /storage/emulated/0/CCA
export DATA="/data/data"
export DATAMEDIA="/data/media/0/Android/data"
export PACKAGE="com.pubg.krmobile"
export FILES="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
export MEDIA="/data/media/0"
chmod -R 777 /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/*/* > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/game_patch*.pak > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/core_patch*.pak > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/lib > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/files > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/app_crashrecord > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/code_cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/no_backups > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/databases > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/vmpcloudconfig.json > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/login-identifier.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/cacheFile.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/ca-bundle.pem > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Engine > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/"Epic Games" > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Paks > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/afd > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/IGH5Cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/PufferTmpDir > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/RoleInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Pandora > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Screenshots > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/UpdateInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content > /dev/null 2>&1
su -c pm install -r /data/app/$PACKAGE*/base.apk /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/lib/* > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/* > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Ori/SrcVersion.ini /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/ > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Korean/* /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks > /dev/null 2>&1
ip6tables -P INPUT ACCEPT
ip6tables -P OUTPUT ACCEPT
ip6tables -P FORWARD ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
fi
if [ -d "/storage/emulated/0/CCA/VN" ];
then
rm -rf /storage/emulated/0/CCA
export DATA="/data/data"
export DATAMEDIA="/data/media/0/Android/data"
export PACKAGE="com.vng.pubgmobile"
export FILES="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
export MEDIA="/data/media/0"
chmod -R 777 /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/* > /dev/null 2>&1
chattr -i $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/*/* > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/game_patch*.pak > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Paks/core_patch*.pak > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/lib > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/files > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/app_crashrecord > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/code_cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/no_backups > /dev/null 2>&1
rm -rf $DATA/$PACKAGE/databases > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/vmpcloudconfig.json > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/login-identifier.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/cacheFile.txt > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/ca-bundle.pem > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Engine > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/"Epic Games" > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/Paks > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/afd > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/IGH5Cache > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/PufferTmpDir > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/RoleInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Pandora > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/Screenshots > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/$FILES/UpdateInfo > /dev/null 2>&1
rm -rf $DATAMEDIA/$PACKAGE/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content > /dev/null 2>&1
su -c pm install -r /data/app/$PACKAGE*/base.apk /data/app/$PACKAGE*/base.apk > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/lib/* > /dev/null 2>&1
chmod -R -R 755 $DATA/$PACKAGE/* > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Ori/SrcVersion.ini /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/ > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/* > /dev/null 2>&1
chmod -R 777 $DATAMEDIA/$PACKAGE/*/*/*/*/*/*/*/ > /dev/null 2>&1
cp /storage/emulated/0/Android/data/com.cleanmaster/cache/files/.CCA/Vietnam/* /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks > /dev/null 2>&1
ip6tables -P INPUT ACCEPT
ip6tables -P OUTPUT ACCEPT
ip6tables -P FORWARD ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
fi
if [ -d "/storage/emulated/0/CCA/TW" ];
then
echo "Restoring File"
rm -rf /data/data/com.rekoo.pubgm/*
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/*
echo "Reinstalling PUBG Mobile Apk"
pm install -r /data/app/com.rekoo.pubgm*/base.apk
su -c iptables --flush
echo "TW"
fi
